-- Create an ER diagram or draw a schema for the given database.

-- 1) We want to reward the user who has been around the longest, Find the 5 oldest users.

SELECT * FROM USERS
ORDER BY created_at ASC
LIMIT 5;

-- 2) To understand when to run the ad campaign, figure out the day of the week most users register on? 

SELECT DAYNAME(created_at) DAY_NAME,
COUNT(*) AS TOTAL FROM USERS
GROUP BY DAY_NAME
ORDER BY TOTAL DESC;

-- 3) To target inactive users in an email ad campaign, find the users who have never posted a photo.
select * from photos WHERE ID IS NULL;
select * from users;

SELECT USERS.USERNAME FROM Users 
WHERE ID NOT IN(SELECT USER_ID FROM PHOTOS);

-- 4) Suppose you are running a contest to find out who got the most likes on a photo. Find out who won?

SELECT * FROM LIKES;
select * from photos;
SELECT * FROM users;

SELECT 
    U.USERNAME,
    PHOTO_ID,
    COUNT(*) AS most_liked
FROM LIKES L
INNER JOIN USERS U ON U.id=L.user_id
GROUP BY photo_id
ORDER BY most_liked DESC
LIMIT 1;
    
-- 5) The investors want to know how many times does the average user post.

SELECT * FROM USERS;
SELECT * FROM PHOTOS;

SELECT (SELECT COUNT(*) FROM PHOTOS) / (SELECT COUNT(*) FROM USERS) AS AVG_USER_POST; 


-- 7) A brand wants to know which hashtag to use on a post, and find the top 5 most used hashtags.

SELECT T.TAG_NAME,COUNT(*) MOST_USED_HASHTAGS FROM TAGS T 
INNER JOIN PHOTO_TAGS PT 
ON PT.TAG_ID = T.ID 
GROUP BY(PT.TAG_ID)
ORDER BY MOST_USED_HASHTAGS DESC
LIMIT 5;

-- 8) To find out if there are bots, find users who have liked every single photo on the site.

SELECT * FROM USERS;
SELECT * FROM PHOTOS;
SELECT * FROM LIKES;

SELECT U.USERNAME,COUNT(*) AS Num_Likes 
FROM  USERS U 
INNER JOIN LIKES L 
ON U.ID = L.USER_ID 
GROUP  BY L.USER_ID;

-- 9) To know who the celebrities are, find users who have never commented on a photo.

-- SELECT * FROM comments;
-- SELECT * FROM USERS ;
-- SELECT DISTINCT USER_ID FROM PHOTOS ORDER BY USER_ID ASC;
-- SELECT DISTINCT USER_ID FROM COMMENTS ORDER BY USER_ID ASC;
-- SELECT ID FROM USERS ORDER BY ID ASC;

SELECT USERNAME FROM USERS
WHERE ID NOT IN ( SELECT DISTINCT C.USER_ID FROM COMMENTS C
INNER JOIN PHOTOS P ON P.USER_ID = C.USER_ID);

/* 10) Now it's time to find both of them together,
find the users who have never commented on any photo or have commented on every photo */

WITH COMMENTED_PHOTO AS (
SELECT DISTINCT USERNAME FROM USERS
WHERE ID IN (SELECT C.USER_ID 
FROM COMMENTS C INNER JOIN PHOTOS P
ON P.USER_ID = C.USER_ID)),
NOT_COMMENT AS(
SELECT DISTINCT USERNAME FROM USERS
WHERE ID NOT IN ( SELECT C.USER_ID FROM COMMENTS C
INNER JOIN PHOTOS P ON P.USER_ID = C.USER_ID))

SELECT * FROM COMMENTED_PHOTO 
UNION ALL 
SELECT * FROM NOT_COMMENT;


